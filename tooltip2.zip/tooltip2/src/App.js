import React from "react";
import "./component/tooltip.css";
import Tooltip from "./component/Tooltip";

class App extends React.Component {
  render() {
    
     return (
        <div className="main-button">
           <Tooltip position={top} />
        </div>
     );
  }
}

export default App;

const top = {
   
};

