import React from "react";
import  "./tooltip.css";


class Tooltip extends React.Component {
   state = { backgroundColor: "green", dialouges: "" };

   // When pointer is hover on button
   onMouseEnter = () => {
      const mystatement = 'Coding ninja is best platform to learn coding ';
      this.setState({ backgroundColor: "#0693E3", dialouges: mystatement });
   };

   
   onMouseLeave = () => {
      this.setState({ backgroundColor: "green", dialouges: "" });
   };

   render() {
      return (
         <div className="tooltip-container">
            <div style={this.props.position}>
               <p>{this.state.dialouges}</p>
            </div>
            <div>
               <button
                  className="tool-button"
                  onMouseEnter={() => this.onMouseEnter()}
                  onMouseLeave={() => this.onMouseLeave()}
                  style={{ backgroundColor: `${this.state.backgroundColor}` }}
               >
                  <h1>Coding Ninja</h1>
               </button>
            </div>
         </div>
      );
   }
}

export default Tooltip;